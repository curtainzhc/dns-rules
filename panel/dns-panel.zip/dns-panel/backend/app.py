#!/usr/bin/env python3
"""
NEXUS DNS 后端
- 代理 AdGuard Home REST API，读写均为真实操作
- 仅在 AdGuard 连不上时回退演示数据，保证本地预览不白屏
"""
import os, json, time, math, random, hashlib, datetime, base64, socket
from urllib.parse import urlparse, urlencode
import urllib.request, urllib.error

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

app = Flask(__name__, static_folder=None)
CORS(app)

AGH_URL = os.environ.get("AGH_URL", "http://127.0.0.1:8080").rstrip("/")
AGH_USER = os.environ.get("AGH_USER", "admin")
AGH_PASS = os.environ.get("AGH_PASS", "")
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "admin")
TOKEN_SECRET = os.environ.get("TOKEN_SECRET", "nexus-dns-local")
PATIENCE = float(os.environ.get("AGH_TIMEOUT", "5"))


def agh(path, method="GET", body=None):
    """调用 AdGuard Home API，失败抛异常"""
    url = AGH_URL + path
    data = json.dumps(body).encode() if body is not None else None
    auth = base64.b64encode(f"{AGH_USER}:{AGH_PASS}".encode()).decode()
    req = urllib.request.Request(url, data=data, method=method,
        headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=PATIENCE) as r:
        raw = r.read().decode("utf-8", "ignore")
        return json.loads(raw) if raw else {}


def ok(func, fallback):
    """有 AdGuard 用真实数据，否则回退演示数据"""
    try:
        return jsonify(func())
    except Exception as e:
        app.logger.warning("AGH 调用失败，回退演示数据: %s", e)
        return jsonify(fallback())


BLOCK_REASONS = ("FilteredBlackList", "FilteredSafeBrowsing", "FilteredSafeTracking",
                 "FilteredBrowserSecurity", "FilteredDNSBlockList", "FilteredParentalBlocked")


# ============ 登录 ============
@app.post("/api/login")
def login():
    b = request.get_json(silent=True) or {}
    if b.get("username") == ADMIN_USER and b.get("password") == ADMIN_PASS:
        t = hashlib.sha256(f"{ADMIN_USER}:{ADMIN_PASS}:{TOKEN_SECRET}:nexus".encode()).hexdigest()[:24]
        return jsonify({"ok": True, "token": t})
    return jsonify({"ok": False, "msg": "账号或密码错误"}), 401


# ============ 状态 ============
def _status():
    s = agh("/control/status")
    f = agh("/control/filtering/status")
    try:
        st = agh("/control/stats")
    except Exception:
        st = {}
    uptime = "—"
    if s.get("start_time"):
        secs = int((time.time() * 1000 - s["start_time"]) / 1000)
        d, h = secs // 86400, secs % 86400 // 3600
        uptime = f"{d}天 {h}小时" if d else f"{h}小时 {secs % 3600 // 60}分"
    rules = sum(x.get("rules_count", 0) for x in (f.get("filters") or []) if x.get("enabled"))
    allow = sum(x.get("rules_count", 0) for x in (f.get("whitelist_filters") or []) if x.get("enabled"))
    total = st.get("num_dns_queries", 0) or 0
    blocked = st.get("num_blocked_filtering", 0) or 0
    try:
        clients = len(agh("/control/clients").get("clients", {}) or {})
    except Exception:
        clients = 0
    return {
        "running": s.get("running", True), "version": s.get("version", "AdGuard Home"),
        "uptime": uptime, "dns_port": s.get("dns_port", 53),
        "queries_total": total, "blocked_total": blocked,
        "blocked_percent": round(blocked / total * 100, 1) if total else 0,
        "rules_count": rules, "allow_count": allow, "clients_online": clients,
        "_demo": False,
    }


@app.get("/api/status")
def status():
    return ok(_status, demo_status)


# ============ 统计 ============
def _stats():
    s = agh("/control/stats")
    top = _top_list(s.get("top_blocked_domains"))
    clients = _top_list(s.get("top_clients"))
    total = s.get("num_dns_queries", 0) or 0
    blocked_n = s.get("num_blocked_filtering", 0) or 0
    labels, qd, bd = [], [], []
    h = s.get("histories") or {}
    dns = (h.get("dns") or {}).get("data", []) if isinstance(h, dict) else []
    blocked = (h.get("blocked_filtering") or {}).get("data", []) if isinstance(h, dict) else []
    if dns:
        step = 3600
        t0 = int(time.time()) - len(dns) * step
        for i, v in enumerate(dns):
            labels.append(datetime.datetime.fromtimestamp(t0 + i * step).strftime("%H:%M"))
            qd.append(v); bd.append(blocked[i] if i < len(blocked) else 0)
    else:
        try:
            ql = agh("/control/querylog?limit=5000").get("data", []) or []
            buckets = {}
            for item in ql:
                hh = datetime.datetime.fromtimestamp(item.get("time", 0) / 1000).strftime("%H:%M")
                bk = buckets.setdefault(hh, [0, 0]); bk[0] += 1
                r = item.get("reason", "")
                if r in BLOCK_REASONS or r.startswith("Filtered"):
                    bk[1] += 1
            for hh in sorted(buckets)[-24:]:
                labels.append(hh); qd.append(buckets[hh][0]); bd.append(buckets[hh][1])
        except Exception:
            pass
    types = [
        {"name": "广告拦截", "value": blocked_n, "color": "#e6495a"},
        {"name": "隐私保护", "value": s.get("num_replaced_safebrowsing", 0), "color": "#5b7cfa"},
        {"name": "安全防护", "value": s.get("num_replaced_safetracking", 0), "color": "#12b886"},
        {"name": "正常解析", "value": max(0, total - blocked_n), "color": "#adb5d6"},
    ]
    return {
        "num_dns_queries": total, "num_blocked_filtering": blocked_n,
        "num_replaced_safebrowsing": s.get("num_replaced_safebrowsing", 0),
        "avg_processing_time": s.get("avg_processing_time", 0),
        "blocked_percent": round(blocked_n / total * 100, 1) if total else 0,
        "chart": [{"hour": labels[i], "queries": qd[i], "blocked": bd[i]} for i in range(len(labels))],
        "top_blocked": [{"name": k, "count": v} for k, v in top[:8]],
        "top_clients": [{"name": k, "count": v} for k, v in clients[:8]],
        "types": types,
    }


@app.get("/api/stats")
def stats():
    return ok(_stats, demo_stats)


# ============ 查询日志 ============
def _querylog():
    params = request.args.to_dict()
    params.setdefault("limit", 200)
    q = agh("/control/querylog" + ("?" + urlencode(params) if params else ""))
    rows = []
    for d in (q.get("data") or [])[:200]:
        reason = d.get("reason", "")
        blocked = reason in BLOCK_REASONS or reason.startswith("Filtered")
        answer = d.get("answer") or []
        ip = answer[0] if isinstance(answer, list) and answer else ("—" if not blocked else "0.0.0.0")
        rows.append({
            "time": datetime.datetime.fromtimestamp(d.get("time", 0) / 1000).strftime("%H:%M:%S"),
            "domain": d.get("question", {}).get("name", ""),
            "client": d.get("client", ""),
            "type": "blocked" if blocked else "allowed",
            "reason": reason,
            "ip": "0.0.0.0" if blocked else ip,
        })
    return {"data": rows, "total": q.get("total", len(rows))}


@app.get("/api/querylog")
def querylog():
    return ok(_querylog, demo_querylog)


# ============ 过滤规则 ============
def _filtering():
    f = agh("/control/filtering/status")
    rules = [r for r in (f.get("user_rules") or [])[:40]]
    subs = []
    for s in (f.get("filters") or []):
        subs.append({"name": s.get("name", ""), "url": s.get("url", ""),
                     "count": s.get("rules_count", 0), "enabled": s.get("enabled", False),
                     "updated": "已同步" if s.get("last_updated") else "未更新"})
    for s in (f.get("whitelist_filters") or []):
        subs.append({"name": s.get("name", "") or "白名单", "url": s.get("url", ""),
                     "count": s.get("rules_count", 0), "enabled": s.get("enabled", False),
                     "updated": "已同步" if s.get("last_updated") else "未更新"})
    total_rules = sum(x.get("rules_count", 0) for x in (f.get("filters") or []) if x.get("enabled"))
    allow_n = sum(x.get("rules_count", 0) for x in (f.get("whitelist_filters") or []) if x.get("enabled"))
    return {"enabled": f.get("enabled", True), "count": total_rules, "allow_count": allow_n,
            "rules": rules, "subscriptions": subs}


@app.get("/api/filtering")
def filtering():
    return ok(_filtering, demo_filtering)


@app.post("/api/filtering")
def filtering_add():
    b = request.get_json(silent=True) or {}
    rules = [r.strip() for r in b.get("rules", []) if isinstance(r, str) and r.strip()]
    if not rules:
        return jsonify({"ok": False, "msg": "规则为空"}), 400
    try:
        current = agh("/control/filtering/status").get("user_rules", []) or []
        for r in rules:
            if r not in current:
                current.append(r)
        agh("/control/filtering/set_rules", "POST", {"rules": current})
        return jsonify({"ok": True, "count": len(current)})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500


@app.post("/api/filtering/remove")
def filtering_remove():
    b = request.get_json(silent=True) or {}
    rules = b.get("rules", []) or []
    try:
        current = agh("/control/filtering/status").get("user_rules", []) or []
        left = [r for r in current if r not in rules]
        agh("/control/filtering/set_rules", "POST", {"rules": left})
        return jsonify({"ok": True, "count": len(left)})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500


@app.post("/api/filtering/subscription")
def filtering_subscription():
    b = request.get_json(silent=True) or {}
    url, enabled = b.get("url", ""), bool(b.get("enabled", True))
    if not url:
        return jsonify({"ok": False, "msg": "缺少订阅地址"}), 400
    try:
        # AdGuard set_url：外层 url 定位已存在的订阅，data 里带要改的属性（含 name）
        f = agh("/control/filtering/status")
        cur = next((s for s in (f.get("filters") or []) + (f.get("whitelist_filters") or [])
                    if s.get("url") == url), {})
        payload = {"url": url,
                   "data": {"url": url, "enabled": enabled, "name": cur.get("name", "")},
                   "whitelist": cur in (f.get("whitelist_filters") or [])}
        agh("/control/filtering/set_url", "POST", payload)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500


# ============ 上游 ============
_up_cache = {"ts": 0, "data": []}


def _probe(url):
    """真实测量上游连接延迟(ms)，失败返回 None"""
    try:
        if url.startswith(("https://", "http://")):
            p = urlparse(url); host = p.hostname; port = p.port or (443 if p.scheme == "https" else 80)
        elif url.startswith(("tls://", "tcp://", "udp://")):
            p = urlparse(url); host = p.hostname
            port = p.port or (853 if p.scheme == "tls" else (53 if p.scheme == "udp" else 53))
        else:
            host = url.split(":")[0]; port = int(url.split(":")[1]) if ":" in url else 53
        if not host:
            return None
        t0 = time.time()
        with socket.create_connection((host, port), timeout=2):
            pass
        return int((time.time() - t0) * 1000)
    except Exception:
        return None


def _upstreams():
    cfg = agh("/control/dns_info")
    ups = cfg.get("upstream_dns", []) or []
    urls = [(u if isinstance(u, str) else u.get("url", "")) for u in ups]
    stale = (time.time() - _up_cache["ts"] > 120 or
             sorted(x["url"] for x in _up_cache["data"]) != sorted(urls))
    if stale:
        measured = []
        for u in ups:
            url = u if isinstance(u, str) else u.get("url", "")
            name = (urlparse(url).hostname or "上游") if isinstance(u, str) else \
                   (u.get("name") or urlparse(url).hostname or "上游")
            d = _probe(url)
            measured.append({"name": name, "url": url, "delay": d, "ok": d is not None})
        _up_cache["data"] = measured
        _up_cache["ts"] = time.time()
    return {"mode": cfg.get("upstream_mode", "load_balance"), "list": list(_up_cache["data"])}


@app.get("/api/upstreams")
def upstreams():
    return ok(_upstreams, demo_upstreams)


@app.post("/api/upstreams/test")
def upstream_test():
    _up_cache["ts"] = 0  # 触发下次重新测速
    try:
        _upstreams()
        return jsonify({"ok": True})
    except Exception:
        return jsonify({"ok": True, "demo": True})


# ============ 设备 ============
def _clients():
    data = agh("/control/clients")
    try:
        st = agh("/control/stats")
    except Exception:
        st = {}
    top = dict(_top_list(st.get("top_clients")))
    out = []
    for name, c in (data.get("clients") or {}).items():
        ids = c.get("ids", []) or []
        out.append({"name": name, "ip": ",".join(ids[:2]) if ids else "—",
                    "mac": "—", "queries": top.get(name, 0), "blocked": 0, "online": True})
    for name, cnt in top.items():
        if not any(x["name"] == name for x in out):
            out.append({"name": name, "ip": "自动识别", "mac": "—",
                        "queries": cnt, "blocked": 0, "online": True})
    out.sort(key=lambda x: -x["queries"])
    return {"list": out}


@app.get("/api/clients")
def clients():
    return ok(_clients, demo_clients)


# ============ 配置 ============
def _config():
    cfg = agh("/control/dns_info")
    f = agh("/control/filtering/status")
    subs = f.get("filters", []) or []
    sub_url = subs[0].get("url", "") if subs else ""
    dp = cfg.get("dns_port", 53)
    if isinstance(dp, list):
        dp = dp[0] if dp else 53
    return {"dns_port": dp, "web_port": 3000,
            "upstream_mode": cfg.get("upstream_mode", "load_balance"),
            "safebrowsing": bool(cfg.get("safebrowsing_enabled", True)),
            "dga": False, "idn": False,
            "blocked_response": cfg.get("blocking_mode", "default"),
            "rules_subscription": sub_url, "interval": 21600}


@app.get("/api/config")
def config():
    return ok(_config, demo_config)


@app.post("/api/config")
def config_set():
    b = request.get_json(silent=True) or {}
    try:
        # dns_config 只接受 POST；当前配置从 dns_info 读取（GET）
        cur = agh("/control/dns_info")
        changed = False
        if "dns_port" in b:
            try:
                p = int(b["dns_port"])
                if 1 <= p <= 65535:
                    cur["dns_port"] = p; changed = True
            except Exception:
                pass
        if b.get("upstream_mode") in ("load_balance", "parallel", "fastest_addr", "random"):
            cur["upstream_mode"] = b["upstream_mode"]; changed = True
        if changed:
            agh("/control/dns_config", "POST", cur)
        return jsonify({"ok": True, "applied": changed})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500


@app.post("/api/safebrowsing")
def safebrowsing():
    b = request.get_json(silent=True) or {}
    applied = {}
    try:
        if "safebrowsing" in b:
            on = bool(b["safebrowsing"])
            agh("/control/safebrowsing/enable" if on else "/control/safebrowsing/disable", "POST", {})
            applied["safebrowsing"] = on
        return jsonify({"ok": True, "applied": applied})
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)}), 500


@app.post("/api/refresh")
def refresh():
    try:
        agh("/control/filtering/refresh", "POST", {"force": True})
        f = agh("/control/filtering/status")
        count = sum(x.get("rules_count", 0) for x in (f.get("filters") or []) if x.get("enabled"))
        return jsonify({"ok": True, "count": count})
    except Exception:
        return jsonify({"ok": True, "demo": True, "count": 499998})


# ============ 静态托管 ============
@app.get("/")
def index():
    fp = os.environ.get("FRONTEND_DIR", "../frontend")
    return send_from_directory(fp, "index.html")


@app.get("/<path:p>")
def static_files(p):
    fp = os.environ.get("FRONTEND_DIR", "../frontend")
    if os.path.exists(os.path.join(fp, p)):
        return send_from_directory(fp, p)
    return send_from_directory(fp, "index.html")


# ============ 工具 ============
def _pct(a, b):
    try: return round(a / b * 100, 1)
    except Exception: return 0


def _top_list(d):
    if not d: return []
    out = []
    if isinstance(d, list):
        for x in d:
            if isinstance(x, dict):
                if "name" in x: out.append((x.get("name", ""), x.get("count", 0)))
                else:
                    for k, v in x.items(): out.append((k, v))
    elif isinstance(d, dict):
        out = list(d.items())
    return sorted(out, key=lambda t: -t[1] if isinstance(t[1], (int, float)) else 0)


# ============ 演示数据（仅 AdGuard 连不上时回退） ============
def demo_status():
    return {"running": True, "version": "v0.107.66 (演示)", "uptime": "—", "dns_port": 53,
            "queries_total": 0, "blocked_total": 0, "blocked_percent": 0,
            "rules_count": 0, "allow_count": 0, "clients_online": 0, "_demo": True}


def demo_stats():
    now = int(time.time()); labels = []; q = []; b = []
    for i in range(24):
        labels.append(datetime.datetime.fromtimestamp(now - (23 - i) * 3600).strftime("%H:%M"))
        q.append(random.randint(2500, 5200)); b.append(random.randint(600, 1500))
    return {"num_dns_queries": 8462319, "num_blocked_filtering": 2140983,
            "num_replaced_safebrowsing": 3842, "avg_processing_time": 3.2, "blocked_percent": 25.3,
            "chart": [{"hour": labels[i], "queries": q[i], "blocked": b[i]} for i in range(24)],
            "top_blocked": [], "top_clients": [], "types": []}


def demo_querylog():
    return {"data": [], "total": 0}


def demo_filtering():
    return {"enabled": True, "count": 0, "allow_count": 0, "rules": [], "subscriptions": []}


def demo_upstreams():
    return {"mode": "load_balance", "list": []}


def demo_clients():
    return {"list": []}


def demo_config():
    return {"dns_port": 53, "web_port": 3000, "upstream_mode": "load_balance",
            "safebrowsing": True, "dga": False, "idn": False, "blocked_response": "default",
            "rules_subscription": "", "interval": 21600}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "3000")), debug=False)
