// 统一数据层：优先请求后端真实 API，失败则用内置演示数据（保证本地预览可用）
const BASE = (window.API_BASE || '');
let TOKEN = sessionStorage.getItem('nexus_token') || '';

export function setToken(t){ TOKEN=t; if(t)sessionStorage.setItem('nexus_token',t); else sessionStorage.removeItem('nexus_token'); }
export function getToken(){ return TOKEN; }

async function req(path,{method='GET',body}={}){
  const r=await fetch(BASE+path,{
    method,
    headers:{'Content-Type':'application/json',...(TOKEN?{'Authorization':'Bearer '+TOKEN}:{})},
    body:body?JSON.stringify(body):undefined,
  });
  if(!r.ok){const e=new Error('HTTP '+r.status);e.status=r.status;throw e}
  return r.json();
}
export const live = {
  login:(u,p)=>req('/api/login',{method:'POST',body:{username:u,password:p}}),
  status:()=>req('/api/status'),
  stats:()=>req('/api/stats'),
  querylog:(params)=>req('/api/querylog'+(params?'?'+new URLSearchParams(params):'')),
  filtering:()=>req('/api/filtering'),
  filteringAdd:(rules)=>req('/api/filtering',{method:'POST',body:{rules}}),
  filteringRemove:(rules)=>req('/api/filtering/remove',{method:'POST',body:{rules}}),
  upstreams:()=>req('/api/upstreams'),
  upstreamTest:()=>req('/api/upstreams/test',{method:'POST'}),
  clients:()=>req('/api/clients'),
  config:()=>req('/api/config'),
  configSet:(patch)=>req('/api/config',{method:'POST',body:patch}),
  safebrowsing:(patch)=>req('/api/safebrowsing',{method:'POST',body:patch}),
  subscription:(patch)=>req('/api/filtering/subscription',{method:'POST',body:patch}),
  refresh:()=>req('/api/refresh',{method:'POST'}),
};

// ============ 演示数据 ============
const rnd=(a,b)=>Math.round(a+Math.random()*(b-a));
function series(base,variance,n=24){
  let v=base;const out=[];
  for(let i=0;i<n;i++){v=Math.max(base*.3,v+rnd(-variance,variance));out.push(v)}
  return out;
}
const hours=Array.from({length:24},(_,i)=>String(i).padStart(2,'0')+':00');
export const demo = {
  login:async()=>({ok:true,token:'demo-token'}),
  status:async()=>({running:true,version:'v0.107.66',uptime:'12天 4小时',dns_port:53,
    queries_total:8462319, blocked_total:2140983, blocked_percent:25.3,
    rules_count:499998, allow_count:12024, clients_online:8}),
  stats:async()=>({
    num_dns_queries:8462319,num_blocked_filtering:2140983,num_replaced_safebrowsing:3842,
    avg_processing_time:3.2, blocked_percent:25.3,
    chart:hours.map((h,i)=>({hour:h,queries:series(3800,900,24)[i]||rnd(2500,5200),blocked:rnd(600,1500)})),
    top_blocked:[
      {name:'doubleclick.net',count:382140},{name:'google-analytics.com',count:294881},
      {name:'ad.qq.com',count:183402},{name:'pagead2.googlesyndication.com',count:152093},
      {name:'gdt.qq.com',count:98441},{name:'bat.bing.com',count:71320},
    ],
    top_clients:[{name:'iPhone 16 Pro',count:2140398},{name:'MacBook Pro',count:1655210},
      {name:'iPad Air',count:982311},{name:'客厅电视',count:712044},{name:'其他设备',count:412341}],
    types:[{name:'广告拦截',value:2140983,color:'#e6495a'},{name:'隐私保护',value:392140,color:'#5b7cfa'},
      {name:'安全防护',value:184203,color:'#12b886'},{name:'正常解析',value:5744000,color:'#adb5d6'}],
  }),
  querylog:async(params)=>{
    const domains=['doubleclick.net','google-analytics.com','ad.qq.com','www.baidu.com','gdt.qq.com',
      'pagead2.googlesyndication.com','www.icloud.com','bat.bing.com','api.cupid.qiyi.com','www.apple.com',
      'umeng.com','cdn.jsdelivr.net','sentry-cdn.com','www.zhihu.com','adservice.google.com'];
    const clients=['iPhone 16 Pro','MacBook Pro','iPad Air','客厅电视'];
    const rows=[];
    for(let i=0;i<40;i++){
      const d=domains[rnd(0,domains.length-1)];
      const blocked=/doubleclick|analytics|ad\.qq|gdt|pagead|bat\.bing|umeng|sentry|adservice/.test(d);
      const t=new Date(Date.now()-i*rnd(8000,40000));
      rows.push({time:t.toLocaleTimeString('zh-CN',{hour12:false}),domain:d,client:clients[rnd(0,3)],
        type:blocked?'blocked':'allowed',reason:blocked?'广告/追踪规则':'—',ip:blocked?'0.0.0.0':`${rnd(13,220)}.${rnd(0,255)}.${rnd(0,255)}.${rnd(1,254)}`});
    }
    return {data:rows,total:2140983};
  },
  filtering:async()=>({enabled:true,count:499998,allow_count:12024,
    rules:['||doubleclick.net^','||google-analytics.com^','||ad.qq.com^','||gdt.qq.com^',
      '||pagead2.googlesyndication.com^','||bat.bing.com^','@@||example.com^'],
    subscriptions:[
      {name:'NEXUS 精简版 50万',url:'https://gh-proxy.com/.../rules-lite.txt',count:499998,enabled:true,updated:'2小时前'},
      {name:'allow 白名单',url:'https://gh-proxy.com/.../allow.txt',count:12024,enabled:false,updated:'2小时前'},
    ]}),
  upstreams:async()=>({mode:'load_balance',list:[
    {name:'Cloudflare DNS',url:'https://cloudflare-dns.com/dns-query',delay:38,ok:true},
    {name:'Google DNS',url:'https://dns.google/dns-query',delay:52,ok:true},
    {name:'阿里 DNS',url:'https://dns.alidns.com/dns-query',delay:16,ok:true},
    {name:'腾讯 DNSPod',url:'https://doh.pub/dns-query',delay:21,ok:true},
    {name:'AdGuard DNS',url:'https://dns.adguard-dns.com/dns-query',delay:76,ok:true},
  ]}),
  upstreamTest:async()=>({ok:true}),
  clients:async()=>({list:[
    {name:'iPhone 16 Pro',ip:'192.168.1.21',mac:'A4:83:E7:**:**:1C',queries:2140398,blocked:602140,online:true},
    {name:'MacBook Pro',ip:'192.168.1.32',mac:'3C:22:FB:**:**:8A',queries:1655210,blocked:410233,online:true},
    {name:'iPad Air',ip:'192.168.1.18',mac:'F0:18:98:**:**:4D',queries:982311,blocked:221094,online:true},
    {name:'客厅电视',ip:'192.168.1.55',mac:'DC:4F:22:**:**:09',queries:712044,blocked:198230,online:true},
    {name:'访客网络',ip:'192.168.1.90',mac:'—',queries:412341,blocked:110486,online:false},
  ]}),
  config:async()=>({dns_port:53,web_port:3000,upstream_mode:'load_balance',
    safebrowsing:true,dga:false,idn:false,blocked_response:'refused',
    rules_subscription:'https://gh-proxy.com/https://raw.githubusercontent.com/curtainzhc/dns-rules/main/data/rules-lite.txt',
    interval:21600}),
  configSet:async()=>({ok:true,applied:false}),
  safebrowsing:async()=>({ok:true}),
  subscription:async()=>({ok:true}),
  refresh:async()=>({ok:true,count:0}),
  filteringAdd:async()=>({ok:true}),
  filteringRemove:async()=>({ok:true}),
};

// 自动选择：能连上后端就用真实，否则演示。
// 登录接口是安全边界：后端明确拒绝(401)时绝不回退到演示令牌，否则任意密码都能进。
export async function api(method){
  const args=Array.prototype.slice.call(arguments,1);
  try{ return await live[method](...args); }
  catch(e){
    if(method==='login'&&e.status)throw e;
    return demo[method](...args);
  }
}
