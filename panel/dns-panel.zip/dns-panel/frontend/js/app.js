import {I,brandLogo} from './icons.js';
import {lineChart,donut,hbar,fmt} from './charts.js';
import {api,setToken,getToken} from './api.js';

const app=document.getElementById('app');
const state={page:'dashboard',data:{},demo:false,logged:!!getToken()};
let toastTimer;
function toast(msg){let t=document.querySelector('.toast');if(!t){t=document.createElement('div');t.className='toast';document.body.appendChild(t)}
  t.textContent=msg;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2200)}
function fmtN(n){return fmt(n)}
function pct(n){return (Number(n)||0).toFixed(1)+'%'}

/* ============ 登录页 ============ */
function loginPage(){
  return `<div class="login-wrap"><div class="login-card">
    <div class="login-hero">
      <div class="logo">${brandLogo}<div>NEXUS DNS<small>DNS CONTROL CENTER</small></div></div>
      <svg class="login-globe" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/></svg>
      <div class="hero-title">让每一次解析，<br>清晰可控。</div>
      <div class="hero-sub">从解析策略到查询洞察，在一个轻盈的工作空间里，管理你的 DNS 网络。</div>
      <div class="hero-tags"><span>解析防护</span><span>个性化规则</span><span>实时观测</span><span>多设备管理</span></div>
    </div>
    <div class="login-form" style="position:relative">
      <button class="theme-toggle" onclick="__toggleTheme()" title="切换主题">${I.moon}</button>
      <h2>欢迎回来</h2><div class="welcome">登录 NEXUS DNS，查看你的网络动态。</div>
      <form onsubmit="__login(event)">
        <div class="field"><label>用户名</label><input id="lu" value="admin" autocomplete="username" placeholder="请输入用户名"></div>
        <div class="field"><label>密码</label><input id="lp" type="password" autocomplete="current-password" placeholder="请输入密码"></div>
        <button class="btn btn-block" type="submit">进入工作空间 →</button>
      </form>
      <div class="login-foot">默认账号 admin，密码见 .env 中的 ADMIN_PASS</div>
    </div>
  </div></div>`;
}

/* ============ 主布局 ============ */
const NAV=[
  {g:'总览',items:[
    {id:'dashboard',name:'仪表盘',icon:'grid'},
    {id:'insight',name:'解析与防护',icon:'shield'},
    {id:'upstream',name:'上游延迟',icon:'gauge'},
  ]},
  {g:'策略',items:[
    {id:'safety',name:'安全',icon:'lock'},
    {id:'rules',name:'自定义规则',icon:'code'},
    {id:'clients',name:'设备配置',icon:'devices'},
  ]},
  {g:'观测',items:[
    {id:'querylog',name:'查询日志',icon:'search'},
  ]},
  {g:'账户',items:[
    {id:'account',name:'账户设置',icon:'users'},
    {id:'settings',name:'全局配置',icon:'settings'},
  ]},
];
const TITLES={dashboard:['仪表盘','网络运行总览'],insight:['解析与防护','拦截趋势与统计'],upstream:['上游延迟','DNS 上游健康检查'],
  safety:['安全','安全策略与过滤开关'],rules:['自定义规则','管理拦截规则与订阅'],clients:['设备配置','已接入的设备'],
  querylog:['查询日志','实时 DNS 查询记录'],account:['账户设置','个人信息与会员权益'],settings:['全局配置','系统参数设置']};

function sidebar(){
  const nav=NAV.map(g=>`<div class="nav-group"><div class="nav-title">${g.g}</div>${g.items.map(it=>
    `<div class="nav-item ${state.page===it.id?'active':''}" onclick="__go('${it.id}')">${I[it.icon]}<span>${it.name}</span></div>`).join('')}</div>`).join('');
  return `<aside class="sidebar" id="sidebar">
    <div class="brand">${brandLogo}<div>NEXUS DNS<small style="display:block;font-size:9px;letter-spacing:1.5px;opacity:.6">CONTROL CENTER</small></div></div>
    <nav>${nav}</nav>
    <div class="sidebar-foot"><div class="u"><div class="avatar">N</div><div><b style="display:block">admin</b><span class="muted">管理员</span></div>
      <button class="icon-btn" style="margin-left:auto;width:32px;height:32px" onclick="__logout()" title="退出">${I.logout}</button></div></div>
  </aside>`;
}
function topbar(){
  const [t,s]=TITLES[state.page];
  const st=state.data.status||{};
  return `<header class="topbar">
    <div class="row"><button class="icon-btn menu-btn" onclick="__toggleSidebar()">${I.menu}</button>
      <div class="crumb">${t}<small>${s}</small></div></div>
    <div class="top-actions">
      <div class="status-pill"><span class="dot ${st.running===false?'off':''}"></span>${st.running===false?'服务已停止':'服务运行中'}</div>
      <button class="icon-btn" onclick="__toggleTheme()" title="切换主题">${document.body.dataset.theme==='dark'?I.sun:I.moon}</button>
      <button class="icon-btn" onclick="__refresh()" title="刷新数据">${I.refresh}</button>
    </div>
  </header>`;
}

/* ============ 页面渲染入口 ============ */
async function render(){
  if(!state.logged){app.innerHTML=loginPage();return}
  await loadData();
  app.innerHTML=`<div class="layout">${sidebar()}<main class="main">${topbar()}<div class="content" id="content">${pageHTML()}</div></main></div>
    <div class="toast"></div>`;
  bindDynamic();
}
async function loadData(){
  const need={
    dashboard:['status','stats'],insight:['stats','status'],upstream:['upstreams'],safety:['config','status'],
    rules:['filtering','status'],clients:['clients','status'],querylog:['querylog'],account:['status'],settings:['config','status'],
  }[state.page]||[];
  await Promise.all(need.map(async k=>{state.data[k]=await api(k)}));
  if(!state.data.status)state.data.status=await api('status');
}
function pageHTML(){
  return ({dashboard:pageDashboard,insight:pageInsight,upstream:pageUpstream,safety:pageSafety,
    rules:pageRules,clients:pageClients,querylog:pageQueryLog,account:pageAccount,settings:pageSettings}[state.page]||pageDashboard)();
}
function bindDynamic(){}

/* ============ 仪表盘 ============ */
function pageDashboard(){
  const s=state.data.stats||{},st=state.data.status||{};
  const stats=[
    {label:'累计查询',value:fmtN(s.num_dns_queries),delta:'AdGuard 实时统计',up:true,ico:I.activity,c:'#3b5bdb'},
    {label:'已拦截请求',value:fmtN(s.num_blocked_filtering),delta:'拦截率 '+pct(s.blocked_percent),up:false,ico:I.shield,c:'#e6495a'},
    {label:'活跃规则',value:fmtN(st.rules_count),delta:'已启用的过滤规则',up:true,ico:I.code,c:'#12b886'},
    {label:'已配置设备',value:(st.clients_online||0),delta:'AdGuard 客户端组',up:true,ico:I.devices,c:'#a06bfa'},
  ];
  const labels=(s.chart||[]).map(x=>x.hour);
  const chart=lineChart([
    {name:'查询',color:'#5b7cfa',data:(s.chart||[]).map(x=>x.queries)},
    {name:'拦截',color:'#e6495a',data:(s.chart||[]).map(x=>x.blocked)},
  ],labels,{height:230});
  const don=donut(s.types||[]);
  const top=(s.top_blocked||[]).slice(0,6).map((x,i)=>`<tr><td style="width:24px;color:var(--muted)">${i+1}</td>
    <td class="mono">${x.name}</td><td style="text-align:right;font-weight:700">${fmtN(x.count)}</td></tr>`).join('');
  return `<div class="page-head"><div><h1>网络总览</h1><p>运行时间 ${st.uptime||'—'} · AdGuard Home ${st.version||''} · 每 6 小时自动更新规则</p></div>
      <button class="btn btn-sm" onclick="__go('querylog')">查看实时日志 →</button></div>
    <div class="grid g4">${stats.map(x=>`<div class="card stat"><div class="label">${x.label}</div>
      <div class="value">${x.value}</div><div class="delta ${x.up?'up':'down'}">${x.up?I.up:I.down}${x.delta}</div>
      <div class="ico" style="background:${x.c}">${x.ico}</div></div>`).join('')}</div>
    <div class="grid g21" style="margin-top:18px">
      <div class="card"><h3>查询趋势 <span class="more" onclick="__go('insight')">查看详情 →</span></h3><div class="chart-box">${chart}</div>
        <div class="legend"><span class="li"><i style="background:#5b7cfa"></i>总查询</span><span class="li"><i style="background:#e6495a"></i>已拦截</span></div></div>
      <div class="card"><h3>拦截构成</h3>${don}</div>
    </div>
    <div class="grid g2" style="margin-top:18px">
      <div class="card"><h3>Top 拦截域名</h3><table class="table"><tbody>${top}</tbody></table></div>
      <div class="card"><h3>设备查询排行</h3>${hbar((s.top_clients||[]).map((c,i)=>({name:c.name,value:c.count,color:['#3b5bdb','#5b7cfa','#12b886','#a06bfa','#adb5d6'][i]})))}</div>
    </div>`;
}

/* ============ 解析与防护 ============ */
function pageInsight(){
  const s=state.data.stats||{},st=state.data.status||{};
  const labels=(s.chart||[]).map(x=>x.hour);
  const chart=lineChart([{name:'查询',color:'#5b7cfa',data:(s.chart||[]).map(x=>x.queries)},
    {name:'拦截',color:'#e6495a',data:(s.chart||[]).map(x=>x.blocked)}],labels,{height:260});
  return `<div class="page-head"><div><h1>解析与防护</h1><p>实时拦截表现与流量构成</p></div></div>
    <div class="grid g4">
      <div class="card stat"><div class="label">总查询</div><div class="value">${fmtN(s.num_dns_queries)}</div><div class="ico" style="background:#3b5bdb">${I.activity}</div></div>
      <div class="card stat"><div class="label">过滤拦截</div><div class="value">${fmtN(s.num_blocked_filtering)}</div><div class="ico" style="background:#e6495a">${I.shield}</div></div>
      <div class="card stat"><div class="label">拦截率</div><div class="value">${pct(s.blocked_percent)}</div><div class="ico" style="background:#12b886">${I.gauge}</div></div>
      <div class="card stat"><div class="label">平均响应</div><div class="value">${s.avg_processing_time||'—'}<span style="font-size:14px">ms</span></div><div class="ico" style="background:#a06bfa">${I.clock}</div></div>
    </div>
    <div class="card" style="margin-top:18px"><h3>24 小时查询 / 拦截趋势</h3><div class="chart-box">${chart}</div>
      <div class="legend"><span class="li"><i style="background:#5b7cfa"></i>总查询</span><span class="li"><i style="background:#e6495a"></i>已拦截</span></div></div>
    <div class="grid g2" style="margin-top:18px">
      <div class="card"><h3>拦截类型分布</h3>${donut(s.types||[])}</div>
      <div class="card"><h3>受影响设备</h3>${hbar((s.top_clients||[]).map((c,i)=>({name:c.name,value:c.count,color:['#3b5bdb','#5b7cfa','#12b886','#a06bfa','#adb5d6'][i]})))}</div>
    </div>`;
}

/* ============ 上游延迟 ============ */
function pageUpstream(){
  const u=state.data.upstreams||{};
  const rows=(u.list||[]).map(x=>`<tr>
    <td><b>${x.name}</b></td><td class="mono muted">${x.url}</td>
    <td><span class="tag ${x.delay<50?'ok':x.delay<100?'blue':'gray'}">${x.delay} ms</span></td>
    <td><span class="tag ${x.ok?'ok':'block'}">${x.ok?'正常':'异常'}</span></td>
    <td style="width:120px"><div class="bar" style="margin:0"><i style="width:${Math.max(8,100-x.delay/1.2)}%;background:${x.delay<50?'#12b886':x.delay<100?'#3b5bdb':'#f59f00'}"></i></div></td>
  </tr>`).join('');
  return `<div class="page-head"><div><h1>上游延迟</h1><p>DNS 上游服务器健康状态与响应速度</p></div>
    <button class="btn btn-sm" onclick="__testUpstream()">${I.refresh} 重新测速</button></div>
    <div class="card"><div class="between" style="margin-bottom:6px"><h3>上游服务器</h3>
      <span class="tag blue">负载均衡模式</span></div>
      <table class="table"><thead><tr><th>名称</th><th>地址</th><th>延迟</th><th>状态</th><th>质量</th></tr></thead><tbody>${rows}</tbody></table>
    </div>
    <div class="card" style="margin-top:18px"><h3>说明</h3>
      <p class="muted" style="font-size:12px;line-height:2;margin-top:8px">
      · 上游 DNS 决定解析速度与隐私；延迟越低响应越快。<br>
      · 当前为负载均衡模式，系统会选用响应最快的上游。<br>
      · 可在「全局配置」中切换为并行请求、备用轮换等模式。</p></div>`;
}

/* ============ 安全 ============ */
function pageSafety(){
  const c=state.data.config||{},st=state.data.status||{};
  const items=[
    {k:'safebrowsing',name:'Google Safe Browsing',desc:'拦截已知钓鱼/恶意网站，本地同步不依赖联网',on:c.safebrowsing},
    {k:'dga',name:'DGA 随机域名拦截',desc:'拦截木马/僵尸网络自动生成的乱码域名',on:c.dga},
    {k:'idn',name:'IDN 同形异义字拦截',desc:'拦截用相似字符伪装的仿冒域名（可能对国际化域名误伤）',on:c.idn},
  ];
  return `<div class="page-head"><div><h1>安全</h1><p>额外的安全过滤层，与规则订阅叠加生效</p></div></div>
    <div class="card"><h3>安全开关</h3>
      ${items.map(x=>`<div class="between" style="padding:18px 0;border-bottom:1px solid var(--line)">
        <div class="row">${I.lock}<div><b style="font-size:13px">${x.name}</b><div class="muted" style="font-size:11px;margin-top:4px">${x.desc}</div></div></div>
        <button class="switch ${x.on?'on':''}" onclick="__toggleSafe('${x.k}',this)"></button></div>`).join('')}
    </div>
    <div class="grid g3" style="margin-top:18px">
      <div class="card stat"><div class="label">已拦截威胁</div><div class="value">${fmtN((state.data.stats||{}).num_replaced_safebrowsing)}</div><div class="ico" style="background:#e6495a">${I.shield}</div></div>
      <div class="card stat"><div class="label">活跃规则总数</div><div class="value">${fmtN(st.rules_count||0)}</div><div class="ico" style="background:#3b5bdb">${I.database}</div></div>
      <div class="card stat"><div class="label">防护状态</div><div class="value" style="font-size:22px">多层防护中</div><div class="ico" style="background:#12b886">${I.lock}</div></div>
    </div>`;
}

/* ============ 自定义规则 ============ */
function pageRules(){
  const f=state.data.filtering||{};
  const rules=(f.rules||[]).map((r,i)=>`<div class="between" style="padding:7px 0;border-bottom:1px solid var(--line)">
    <span class="mono">${r.replace(/</g,'&lt;')}</span><button class="icon-btn" style="width:26px;height:26px" title="删除" onclick="__removeRule(${i})">${I.trash}</button></div>`).join('');
  if(!rules)state._rules=f.rules||[];
  const subs=(f.subscriptions||[]).map((s,i)=>`<div class="between" style="padding:14px 0;border-bottom:1px solid var(--line)">
    <div><b style="font-size:13px">${s.name}</b><div class="mono muted" style="font-size:10px;margin-top:4px;max-width:420px">${s.url||'（本地规则组）'}</div></div>
    <div class="row"><span class="tag ${s.enabled?'ok':'gray'}">${fmtN(s.count)} 条</span>
      <button class="switch ${s.enabled?'on':''}" onclick="__toggleSub(${i},this)"></button></div></div>`).join('');
  if(!subs)state._subs=f.subscriptions||[];
  return `<div class="page-head"><div><h1>自定义规则</h1><p>拦截规则、放行白名单与订阅源管理</p></div>
    <button class="btn btn-sm" onclick="__addRule()">${I.plus} 添加规则</button></div>
    <div class="grid g4" style="margin-bottom:18px">
      <div class="card stat"><div class="label">拦截规则</div><div class="value">${fmtN(f.count)}</div><div class="ico" style="background:#e6495a">${I.shield}</div></div>
      <div class="card stat"><div class="label">白名单</div><div class="value">${fmtN(f.allow_count)}</div><div class="ico" style="background:#12b886">${I.check}</div></div>
      <div class="card stat"><div class="label">过滤状态</div><div class="value" style="font-size:22px;color:var(--ok)">已启用</div><div class="ico" style="background:#3b5bdb">${I.activity}</div></div>
      <div class="card stat"><div class="label">订阅源</div><div class="value">${(f.subscriptions||[]).length}</div><div class="ico" style="background:#a06bfa">${I.database}</div></div>
    </div>
    <div class="grid g2">
      <div class="card"><h3>规则订阅源</h3>${subs}</div>
      <div class="card"><h3>自定义规则</h3>${rules||'<div class="muted" style="font-size:12px;padding:8px 0">暂无自定义规则</div>'}
        <div class="row" style="margin-top:14px;gap:8px"><input id="ruleInput" class="search" style="flex:1" placeholder="输入规则，如 ||ads.example.com^">
          <button class="btn btn-sm" onclick="__addRule()">${I.plus} 添加</button></div>
        <div class="code" style="margin-top:12px">语法示例：\n||域名^            拦截域名\n@@||域名^          放行域名\n||域名^$important  强制拦截</div>
      </div>
    </div>`;
}

/* ============ 设备配置 ============ */
function pageClients(){
  const list=(state.data.clients||{}).list||[];
  const rows=list.map(c=>`<tr>
    <td><div class="row"><span class="dot ${c.online?'':'off'}"></span><b>${c.name}</b></div></td>
    <td class="mono muted">${c.ip}</td><td class="mono muted">${c.mac}</td>
    <td>${fmtN(c.queries)}</td><td><span class="tag block">${fmtN(c.blocked)}</span></td>
    <td><span class="tag ${c.online?'ok':'gray'}">${c.online?'在线':'离线'}</span></td></tr>`).join('');
  return `<div class="page-head"><div><h1>设备配置</h1><p>已接入 DNS 服务的设备与拦截表现</p></div></div>
    <div class="card"><h3>设备列表</h3><table class="table"><thead><tr><th>设备</th><th>IP</th><th>MAC</th><th>查询数</th><th>拦截数</th><th>状态</th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="card" style="margin-top:18px"><h3>接入方式</h3>
      <div class="code" style="margin-top:10px">DoH 地址： https://你的域名/dns-query\nDoT 地址： tls://你的域名\n普通 DNS： 你的服务器 IP:53\n\n在手机/路由器 DNS 设置中填入以上地址即可接入。</div></div>`;
}

/* ============ 查询日志 ============ */
function pageQueryLog(){
  const rows=((state.data.querylog||{}).data||[]).map(r=>`<tr>
    <td class="mono muted">${r.time}</td><td class="mono">${r.domain}</td><td>${r.client}</td>
    <td><span class="tag ${r.type==='blocked'?'block':'ok'}">${r.type==='blocked'?'已拦截':'放行'}</span></td>
    <td class="muted">${r.reason}</td><td class="mono muted">${r.ip}</td></tr>`).join('');
  return `<div class="page-head"><div><h1>查询日志</h1><p>实时 DNS 请求记录（最近 40 条）</p></div>
    <button class="btn btn-sm btn-ghost" onclick="__refresh()">${I.refresh} 刷新</button></div>
    <div class="toolbar"><input class="search" id="logSearch" placeholder="搜索域名 / 设备..." oninput="__filterLog()">
      <div class="pill-tabs"><button class="on" onclick="__logTab(this,'all')">全部</button>
        <button onclick="__logTab(this,'blocked')">已拦截</button><button onclick="__logTab(this,'allowed')">放行</button></div></div>
    <div class="card" style="padding:12px 18px"><table class="table" id="logTable"><thead><tr><th>时间</th><th>域名</th><th>设备</th><th>结果</th><th>原因</th><th>解析 IP</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

/* ============ 账户 ============ */
function pageAccount(){
  const st=state.data.status||{};
  return `<div class="page-head"><div><h1>账户设置</h1><p>个人信息与权益</p></div></div>
    <div class="grid g2">
      <div class="card"><h3>个人信息</h3>
        <div class="row" style="margin-top:18px"><div class="avatar" style="width:56px;height:56px;font-size:20px">N</div>
          <div><b style="font-size:16px">admin</b><div class="muted" style="font-size:12px;margin-top:4px">管理员 · 本地部署</div></div></div>
        <div style="margin-top:20px;font-size:12px;line-height:2.4" class="muted">
          服务版本：${st.version||'—'}<br>运行时间：${st.uptime||'—'}<br>部署方式：Docker Compose</div>
      </div>
      <div class="card"><h3>${I.crown} 会员权益</h3>
        <p class="muted" style="font-size:12px;margin-top:10px;line-height:1.9">本项目为自建 DNS 服务，所有功能本地可用，无会员限制。以下为参考权益说明：</p>
        <div style="margin-top:16px">
          ${['50 万条精简拦截规则','实时查询日志与统计','多设备统一管理','每 6 小时自动更新规则','自定义规则与白名单'].map(x=>
            `<div class="row" style="margin-bottom:10px;font-size:13px"><span style="color:var(--ok)">${I.check}</span>${x}</div>`).join('')}
        </div>
      </div>
    </div>`;
}

/* ============ 全局配置 ============ */
function pageSettings(){
  const c=state.data.config||{};
  return `<div class="page-head"><div><h1>全局配置</h1><p>系统参数与规则订阅设置</p></div>
    <button class="btn btn-sm" onclick="__saveConfig()">${I.check} 保存配置</button></div>
    <div class="grid g2">
      <div class="card"><h3>服务参数</h3>
        <div class="field"><label>DNS 端口</label><input id="cfgPort" value="${c.dns_port||53}"></div>
        <div class="field"><label>上游模式</label><select id="cfgMode" style="width:100%;height:44px;border:1px solid var(--line);border-radius:11px;background:var(--bg);color:var(--text);padding:0 12px">
          <option value="load_balance" ${c.upstream_mode==='load_balance'?'selected':''}>负载均衡</option>
          <option value="parallel" ${c.upstream_mode==='parallel'?'selected':''}>并行请求</option>
          <option value="fastest_addr" ${c.upstream_mode==='fastest_addr'?'selected':''}>最快地址</option></select></div>
        <div class="field"><label>规则更新间隔（秒）</label><input id="cfgInterval" value="${c.interval||21600}"></div>
      </div>
      <div class="card"><h3>规则订阅</h3>
        <div class="field"><label>订阅地址</label><textarea id="cfgSub" rows="4" style="width:100%;border:1px solid var(--line);border-radius:11px;background:var(--bg);color:var(--text);padding:10px;font-size:11px;font-family:monospace;resize:vertical">${c.rules_subscription||''}</textarea></div>
        <button class="btn btn-sm btn-ghost" onclick="__refreshRules()">${I.refresh} 立即更新规则</button>
        <p class="muted" style="font-size:11px;margin-top:12px;line-height:1.7">更新会从上方订阅地址重新拉取。当前规则数：${fmtN(state.data.status?.rules_count||0)} 条。</p>
      </div>
    </div>`;
}

/* ============ 交互函数（挂到 window） ============ */
window.__go=async(id)=>{state.page=id;state.data={};await render();window.scrollTo(0,0)};
window.__toggleTheme=()=>{const d=document.body.dataset.theme;document.body.dataset.theme=d==='dark'?'light':'dark'};
window.__toggleSidebar=()=>document.getElementById('sidebar').classList.toggle('open');
window.__login=async(e)=>{e.preventDefault();const u=document.getElementById('lu').value,p=document.getElementById('lp').value;
  try{const r=await api('login',u,p);if(r.token){setToken(r.token);state.logged=true;await render()}else toast(r.msg||'登录失败')}
  catch(err){toast(err.status===401?'账号或密码错误':'无法连接服务，请检查后端')}};
window.__logout=()=>{setToken('');state.logged=false;render()};
window.__refresh=async()=>{await render();toast('数据已刷新')};
window.__testUpstream=async()=>{toast('正在测速...');await api('upstreamTest');state.data.upstreams=await api('upstreams');render();toast('测速完成')};
window.__toggleSafe=async(k,el)=>{el.classList.toggle('on');const on=el.classList.contains('on');
  const r=await api('safebrowsing',{[k]:on});toast(r.ok===false?(r.msg||'操作失败'):((on?'已开启':'已关闭')+' '+k))};
window.__addRule=async()=>{const inp=document.getElementById('ruleInput');const d=inp?.value?.trim();
  if(!d){toast('请输入规则');return}
  const r=await api('filteringAdd',[d]);
  if(r.ok===false){toast('添加失败：'+(r.msg||'请检查连接'));return}
  inp.value='';toast('规则已添加');state.data.filtering=await api('filtering');render()};
window.__removeRule=async(i)=>{const r=await api('filteringRemove',[(state._rules||[])[i]]);
  if(r.ok===false){toast('删除失败：'+(r.msg||''));return}
  toast('规则已删除');state.data.filtering=await api('filtering');render()};
window.__toggleSub=async(i,el)=>{const s=(state._subs||[])[i];if(!s||!s.url){toast('本地规则组请在 AdGuard 管理');return}
  el.classList.toggle('on');const on=el.classList.contains('on');
  const r=await api('subscription',{url:s.url,enabled:on});
  toast(r.ok===false?(r.msg||'操作失败'):(on?'订阅已启用':'订阅已暂停'))};
window.__saveConfig=async()=>{const r=await api('configSet',{dns_port:document.getElementById('cfgPort').value,
  upstream_mode:document.getElementById('cfgMode').value,interval:+document.getElementById('cfgInterval').value,
  rules_subscription:document.getElementById('cfgSub').value});
  toast(r.ok===false?(r.msg||'保存失败'):(r.applied?'配置已保存并生效':'配置已保存'))};
window.__refreshRules=async()=>{toast('正在拉取规则...');const r=await api('refresh');toast(r.ok===false?'更新失败':'规则已更新：'+fmtN(r.count||0)+' 条')};
window.__filterLog=()=>{const q=document.getElementById('logSearch').value.toLowerCase();
  document.querySelectorAll('#logTable tbody tr').forEach(tr=>tr.style.display=tr.textContent.toLowerCase().includes(q)?'':'none')};
window.__logTab=(el,t)=>{el.parentElement.querySelectorAll('button').forEach(b=>b.classList.remove('on'));el.classList.add('on');
  document.querySelectorAll('#logTable tbody tr').forEach(tr=>tr.style.display=(t==='all'||tr.textContent.includes(t==='blocked'?'已拦截':'放行'))?'':'none')};

render();
