// 纯 SVG 图表，无第三方依赖
const esc = s => String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

// 折线/面积图 series:[{name,color,data:[]}] labels:[]
export function lineChart(series, labels, {height=210, area=true}={}){
  const W=640,H=height,pad={l:38,r:14,t:14,b:26};
  const totalPts=series.reduce((a,s)=>a+(s.data||[]).reduce((x,y)=>x+(y||0),0),0);
  if(!labels.length || totalPts<=6){
    return `<div style="height:${height}px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--muted);gap:8px">
      <svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.5" opacity=".5"><path d="M3 12h4l3-8 4 16 3-8h4"/></svg>
      <span style="font-size:12px">数据积累中，稍后即可查看趋势</span></div>`;
  }
  const iw=W-pad.l-pad.r, ih=H-pad.t-pad.b;
  const max=Math.max(1,...series.flatMap(s=>s.data));
  const n=Math.max(1,...series.map(s=>s.data.length));
  const x=i=>pad.l+(n===1?iw/2:i/(n-1)*iw);
  const y=v=>pad.t+ih-(v/max)*ih;
  let g='';
  // 网格 + Y轴刻度
  for(let i=0;i<=4;i++){
    const yy=pad.t+ih-(i/4)*ih;
    g+=`<line x1="${pad.l}" y1="${yy}" x2="${W-pad.r}" y2="${yy}" stroke="currentColor" stroke-opacity=".08"/>`;
    g+=`<text x="${pad.l-8}" y="${yy+4}" text-anchor="end" font-size="10" fill="currentColor" opacity=".45">${fmtK(max*i/4)}</text>`;
  }
  let paths='';
  series.forEach(s=>{
    const pts=s.data.map((v,i)=>`${x(i)},${y(v)}`).join(' ');
    if(area && s.fill!==false){
      paths+=`<polygon points="${pad.l},${pad.t+ih} ${pts} ${x(s.data.length-1)},${pad.t+ih}" fill="${s.color}" opacity=".12"/>`;
    }
    paths+=`<polyline points="${pts}" fill="none" stroke="${s.color}" stroke-width="2.3" stroke-linejoin="round" stroke-linecap="round"/>`;
    s.data.forEach((v,i)=>{paths+=`<circle cx="${x(i)}" cy="${y(v)}" r="2.6" fill="${s.color}" stroke="var(--card-solid)" stroke-width="1.5"/>`});
  });
  // X轴标签（稀疏）
  const step=Math.max(1,Math.ceil(n/6));
  let xl='';
  for(let i=0;i<n;i+=step){xl+=`<text x="${x(i)}" y="${H-6}" text-anchor="middle" font-size="10" fill="currentColor" opacity=".45">${esc(labels[i]||'')}</text>`}
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="width:100%;height:${height}px;overflow:visible;color:var(--text)">${g}${paths}${xl}</svg>`;
}

export function donut(items,{size=180}={}){
  const total=items.reduce((a,b)=>a+b.value,0)||1;
  const r=70,cx=90,cy=90,cir=2*Math.PI*r;
  let off=0,segs='';
  items.forEach(it=>{
    const len=it.value/total*cir;
    segs+=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${it.color}" stroke-width="22"
      stroke-dasharray="${len} ${cir-len}" stroke-dashoffset="${-off}" transform="rotate(-90 ${cx} ${cy})"/>`;
    off+=len;
  });
  const legend=items.map(it=>`<span class="li"><i style="background:${it.color}"></i>${esc(it.name)} ${(it.value/total*100).toFixed(0)}%</span>`).join('');
  return `<div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap">
    <svg viewBox="0 0 180 180" style="width:${size}px;height:${size}px;flex:none">
      ${segs}
      <text x="90" y="86" text-anchor="middle" font-size="26" font-weight="800" fill="var(--text)">${fmtK(total)}</text>
      <text x="90" y="106" text-anchor="middle" font-size="11" fill="var(--muted)">总计</text>
    </svg>
    <div class="legend" style="flex-direction:column;gap:9px">${legend}</div>
  </div>`;
}

export function hbar(items,{max}={}){
  const m=max||Math.max(1,...items.map(i=>i.value));
  return items.map(it=>`<div style="margin-bottom:13px">
    <div class="between" style="font-size:12px;margin-bottom:5px"><span>${esc(it.name)}</span><span class="muted mono">${fmtK(it.value)}</span></div>
    <div class="bar" style="margin:0"><i style="width:${it.value/m*100}%;background:${it.color||'linear-gradient(90deg,var(--brand),#a06bfa)'}"></i></div>
  </div>`).join('');
}

export function sparkline(data,color='var(--brand)',{w=90,h=30}={}){
  const max=Math.max(1,...data),min=Math.min(...data),rng=max-min||1;
  const pts=data.map((v,i)=>`${i/(data.length-1||1)*w},${h-2-(v-min)/rng*(h-6)}`).join(' ');
  return `<svg viewBox="0 0 ${w} ${h}" style="width:${w}px;height:${h}px"><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round"/></svg>`;
}

function fmtK(n){
  n=Number(n)||0;
  if(n>=1e8)return (n/1e8).toFixed(1)+'亿';
  if(n>=1e4)return (n/1e4).toFixed(n>=1e6?0:1)+'万';
  if(n>=1000)return (n/1000).toFixed(1)+'k';
  return Math.round(n).toString();
}
export const fmt=fmtK;
