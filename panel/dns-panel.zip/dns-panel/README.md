# NEXUS DNS · 自建 DNS 服务 + 管理面板

一个**真正能用的 DNS 服务**：AdGuard Home 作 DNS 内核（真实解析 + 广告拦截 + 统计日志），外面套一套自研管理面板，风格参考 XLXBK DNS，数据全部来自真实服务。已接入 [50 万精简规则订阅](https://github.com/curtainzhc/dns-rules)。

## 功能

| 模块 | 说明 | 数据来源 |
|---|---|---|
| 仪表盘 | 累计查询、拦截数、拦截率、活跃规则、在线设备、查询趋势、拦截构成 | 真实 |
| 解析与防护 | 24h 查询/拦截趋势、类型分布、设备排行 | 真实 |
| 上游延迟 | 上游 DNS 地址、延迟、健康状态、测速 | 真实 |
| 安全 | Safe Browsing / DGA / IDN 开关 | 真实 |
| 自定义规则 | 规则订阅源、拦截/放行规则 | 真实 |
| 设备配置 | 已接入设备、查询/拦截数、接入方式 | 真实 |
| 查询日志 | 实时 DNS 查询、域名、设备、结果、原因 | 真实 |
| 账户 / 全局配置 | 登录、服务参数、订阅地址、立即更新规则 | 真实 |

## 一、本地预览（在本机跑）

已验证环境：Ubuntu 22.04 / Docker 27.5。

```bash
cd dns-panel
cp .env.example .env
docker compose up -d
```

打开：

- **管理面板**：http://localhost:3000　账号 `admin` / 密码 `Admin123456`
- **AdGuard 原生管理页**：http://localhost:8080　同账号密码

验证 DNS 拦截（本机把 DNS 指向 127.0.0.1 或用 dig）：

```bash
dig @127.0.0.1 doubleclick.net +short   # 返回 0.0.0.0 = 拦截成功
dig @127.0.0.1 www.baidu.com +short     # 返回真实 IP = 解析正常
```

## 二、部署到服务器

### 准备

1. 一台有公网 IP 的 Linux 服务器（建议 1核2G 以上），安装 Docker + Docker Compose。
2. 安全组/防火墙放行：**TCP 3000**（面板）、**TCP/UDP 53**（DNS）。
3. 如需域名访问面板，可再用 Nginx + Let's Encrypt 反代 3000 端口（可选）。

### 部署

```bash
# 上传整个 dns-panel 目录到服务器
cd dns-panel

# 修改默认密码（重要！）
cp .env.example .env
vim .env        # 改 ADMIN_PASS / AGH_PASS / TOKEN_SECRET

# 同步修改 AdGuard 内部密码（见下方"改密码"）

# 启动
docker compose up -d

# 查看状态
docker compose ps
docker compose logs -f
```

访问 `http://服务器IP:3000` 即可。

### 客户端接入

在手机/路由器/电脑的 DNS 设置里填入：

- 普通 DNS：`服务器IP`
- DoT：`tls://服务器IP`（需配 TLS 证书，可选）
- DoH：`https://你的域名/dns-query`（需反代 + 证书，可选）

家庭网络建议直接在**路由器 DHCP** 里把 DNS 指向这台服务器，全屋设备自动生效。

## 三、改密码（重要）

默认密码是 `Admin123456`，部署后务必修改，两处要一致：

1. **面板登录密码**：改 `.env` 里的 `ADMIN_PASS`，重启 panel 容器。
2. **AdGuard 管理密码**：进 http://IP:8080 → 设置 → 管理员密码修改；或在 AdGuard 里改完后同步 `.env` 的 `AGH_PASS`（面板靠它调 AdGuard API）。

## 四、规则更新

规则订阅地址写在 AdGuard 里（`deploy/agh/conf/AdGuardHome.yaml` 的 `filters`），默认每 24 小时自动更新，源地址为：

```
https://gh-proxy.com/https://raw.githubusercontent.com/curtainzhc/dns-rules/main/data/rules-lite.txt
```

面板「全局配置 → 立即更新规则」可手动触发。上游源每 6 小时更新一次，本服务按需拉取。

## 五、目录结构

```
dns-panel/
├── docker-compose.yml       # 一键编排
├── .env.example             # 环境变量示例
├── README.md                # 本文档
├── frontend/                # 管理面板（纯静态，无需构建）
│   ├── index.html
│   ├── css/style.css
│   └── js/{app,api,charts,icons}.js
├── backend/                 # API 服务
│   ├── app.py               # Flask：代理 AdGuard API + 演示数据兜底
│   ├── Dockerfile
│   └── requirements.txt
└── deploy/agh/              # AdGuard Home 持久化状态（含配置+规则缓存）
    ├── conf/AdGuardHome.yaml
    └── work/                # 规则缓存、查询日志数据库
```

## 六、技术说明

- **为什么用 AdGuard Home**：成熟稳定，DNS 层拦截可靠，自带统计/日志/客户端管理 API；你的规则本来就是 AdGuard 格式。
- **面板不碰 DNS 转发**：面板只调用 AdGuard API 读写配置/拉数据，DNS 解析完全由 AdGuard 处理，互不干扰。
- **无数据时兜底**：连不上 AdGuard 时面板自动用演示数据，保证界面可预览；连上后全部切真实数据。
- **端口**：面板 3000、AdGuard 原生页 8080（仅本机 127.0.0.1）、DNS 53。

## 七、常见问题

- **53 端口被占用**：服务器若有 systemd-resolved，先 `systemctl stop systemd-resolved` 或改 AdGuard 监听地址。
- **面板显示演示数据**：说明 `AGH_URL` 连不上 AdGuard，检查容器网络（Compose 内用服务名 `adguard:3000`）和密码。
- **规则没拦广告**：确认订阅已启用（面板自定义规则页）、防护开关已开（AdGuard protection_enabled）。
